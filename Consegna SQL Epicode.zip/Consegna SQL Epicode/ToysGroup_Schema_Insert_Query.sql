create database ToysGroup;

use ToysGroup;

   create table Category (
	Category_ID INT PRIMARY KEY 
	,Category_Name VARCHAR (20));
    
    
create table Product (
	 Product_ID INT PRIMARY KEY 
	,Product_Name VARCHAR (30)
    ,Reccomended_Age VARCHAR (10)
    ,UnitPrice DECIMAL (10,2)
    ,StartContract_Date DATE
    ,End_ContractDate DATE
    ,Status_ VARCHAR (10)
    ,Category_ID INT
	,foreign key (Category_ID) references Category (Category_ID)) ;
    
    
    create table Region (
	Territory_ID INT PRIMARY KEY 
    ,Region_Name VARCHAR (20)
    ,Countries VARCHAR (20)
    ,Store_Name VARCHAR (30)
    ,Email_Store VARCHAR (30));

create table Sales (
	Sales_ID INT PRIMARY KEY 
   ,UnitPrice DECIMAL (10,2)
   ,OrderQuantity INT 
   ,Sales_Date DATE 
   ,Product_ID INT
   ,Territory_ID INT
   ,foreign key (Product_ID) references Product (Product_ID)
   ,foreign key (Territory_ID) references Region (Territory_ID ));
   
   /* Table: Category
	  Category_ID: ID della categoria
      Category_Name: Nome categoria giocattolo
      
      Table: Product:
      ProductID: ID del prodotto
      Product_Name: Nome del prodotto
      Reccomended_Age: Età raccomandata per l'uso del giocattolo
      StartContract_Date: Data stipula contratto fornitura del prodotto
      End_ContractDate: Data fine contratto fornitura del prodotto
      Status_: Status produzione del prodotto
      
      Table: Region
      Territory_ID: ID area Stato/Regione
      Region_Name:Nome Regione
      Countries: Stato
      Store_Name: Nome dello store cliente fortnitura
      Email_Store: Contatto store
      
      Table:Sales
      SalesID: ID transazione
      UnitePrice: Prezzo unità singola prodotto
      OrderQuantity: Quantità acquistata nella transazione
      Sales_Date: Data di acquisto
      */
   
   
INSERT INTO Category (Category_ID, Category_Name)
VALUES 

					(1, 'Toys'),
					(2, 'Games'),
					(3, 'Educational'),
					(4, 'Outdoor Toys'),
					(5, 'Board Games'),
					(6, 'Building Blocks'),
					(7, 'Plush Toys'),
					(8, 'Art and Craft'),
					(9, 'Sports Equipment');
    
INSERT INTO Product (Product_ID, Product_Name, Reccomended_Age,UnitPrice, StartContract_Date, End_ContractDate, Status_ , Category_ID)
VALUES

					(1,'Action Figure', '3+',10.99,	'2023-01-01', '2028-12-31','Current', 1),
					(2,'Puzzle', '6+',	15.99, '2023-02-01', '2028-12-31','Current', 2),
					(3,'Robot', '8+', 19.99	, '2023-03-01', '2027-12-31','Current', 1),
					(4,'Dollhouse', '3+', 29.99,'2023-04-01', '2028-12-31','Current', 4),
					(5,'Chess Set', '8+', 39.99,'2023-05-01', '2027-12-31','Current', 5),
					(6,'LEGO Classic', '5+',  49.99,'2023-06-01', '2029-12-31','Current', 6),
					(7,'Teddy Bear', '3+', 19.99,'2023-07-01', '2028-12-31', 'Current', 7),
					(8,'Painting Set', '6+', 9.99,'2023-08-01', '2027-12-31', 'Current', 8),
					(9,'Basketball Hoop', '8+',	 59.99 ,'2023-09-01', '2029-12-31','Current', 9),
					(10,'Remote-Controlled Helicopter', '10+', 49.99,'2023-10-01', '2029-12-31','Current', 1),
					(11,'Toy Kitchen Playset', '3+', 29.99,	 '2023-11-01', '2029-12-31','Current', 3),
					(12,'Building Blocks Castle', '5+', 39.99, '2023-12-01', '2028-12-31','Current', 6), 
					(13,'Remote-Controlled Boat', '8+', 59.99,	'2023-01-01', '2029-12-31','Current', 1),
					(14,'Educational Laptop', '5+', 79.99,'2023-02-01', '2028-12-31', 'Current', 3),
					(15,'Wooden Train Set', '3+',39.99,	'2023-03-01', '2028-12-31', 'Current', 6),
					(16,'RC Airplane', '10+', 49.99,'2023-04-01', '2028-12-31', 'Current', 1),
					(17,'Science Experiment Kit', '8+',	29.99,'2023-05-01', '2029-12-31', 'Current', 3),
					(18,'Toy Telescope', '6+',	39.99,	 '2023-06-01', '2028-12-31','Current', 6),
					(19,'Remote-Controlled Drone', '10+',  79.99,'2023-07-01', '2029-12-31', 'Current', 1),
					(20,'Artificial Intelligence Robot', '8+',	99.99, '2023-08-01', '2028-12-31', 'Current', 3),
					(21,'Wooden Puzzle Set', '6+',	49.99,	'2023-09-01', '2029-12-31', 'Current', 6)

;

INSERT INTO Region (Territory_ID, Countries, Region_Name, Store_Name, Email_Store)
VALUES

					(1,	 'Italy',	 'Sicily',	 'Toy Land',	 'toyland@gmail'),
					(2,	 'France',	 'Occitanie',	 'Toy World',	 'toyworld@gmail'),
					(3,	 'Italy',	 'Tuscany',	 'Toy Universe',	 'toyuniverse@gmail'),
					(4,	 'France',	 'Corsica',	 'Toy World',	 'toyworld@gmail'),
					(5,	 'Italy',	 'Lombardy',	 'Toy Universe',	 'toyuniverse@gmail'),
					(6,	 'Germany',	 'Sassonia',	 'Toy Haven',	 'toyhaven@gmail'),
					(7,	 'France',	 'Bretagna' ,	 'Toy Plaza',	 'toyplaza@gmail'),
					(8,	 'Germany',	 'Brema',	 'Toy Emporium',	 'toyemporium@gmail'),
					(9,	 'Italy',	 'Lazio',	 'Toy Central',	 'toycentral@gmail'),
					(10, 'Germany',	 'Brandeburgo',	 'Toy World',	 'toyworldberlin@gmail'),
					(11, 'Germnay',	 'Sassonia',	 'Toy Planet',	 'toyplanet@gmail'),
					(12, 'France',	 'Île-de-France',	 'Toy Emporium',	 'toyemporiumflorida@gmail'),
					(13, 'Italy',	 'Apulia',	 'Toy Kingdom',	 'toykingdombrazil@gmail'),
					(14, 'Germany',	 'Sassonia-Anhalt',	 'Toy Land',	 'toylandrussia@gmail') 
                    
                    ;
 
 INSERT INTO Sales (Sales_ID, UnitPrice, OrderQuantity, Sales_Date, Product_ID, Territory_ID)
VALUES

					(1, 10.99, 50, '2023-01-15', 1, 1),
					(2, 15.99, 30, '2023-02-20', 2, 2),
					(3, 49.99, 20, '2023-03-25', 6, 3),
					(4, 59.99, 10, '2023-04-10', 9, 4),
					(5, 29.99, 15, '2023-05-15', 4, 5),
					(6, 49.99, 20, '2023-06-20', 6, 6),
					(7, 19.99, 25, '2023-07-10', 7, 7),
					(8, 29.99, 50, '2023-08-15', 17, 8),
					(9, 59.99, 10, '2023-09-20', 9, 9),
					(10, 49.99, 15, '2023-10-10', 10, 10),
					(11, 49.99, 20, '2023-11-15', 10, 11),
					(12, 39.99, 25, '2023-12-20', 12, 1),
					(13, 49.99, 10, '2023-01-10', 16, 1),
					(14, 79.99, 8, '2023-02-15', 14, 14),
					(15, 39.99, 15, '2023-03-20', 15, 14),
					(16, 49.99, 12, '2023-04-10', 16, 6),
					(17, 29.99, 18, '2023-05-15', 17, 5),
					(18, 19.99, 20, '2023-06-20', 3, 2),
					(19, 79.99, 10, '2023-07-10', 19, 12),
					(20, 99.99, 8, '2023-08-15', 20, 7),
					(21, 49.99, 15, '2023-09-20', 21, 14)
;
 


-- 1. Verificare che i campi definiti come PK siano univoci. 

select category_id, count(*) ConteggioRecord
from category
group by category_ID 
having count(*) > 1;

select product_ID, count(*) ConteggioRecord
from product 
group by Product_ID
having count(*) > 0
order by count(*) desc;

select count(*) ConteggioRecord
from region 
group by Territory_ID
having count(*) > 1;

select count(*) ConteggioRecord
from sales
group by Sales_ID
having count(*) > 1;

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

select 
	p.Product_Name,
    year(Sales_Date) Annual_Revenue,
	sum(s.UnitPrice*s.OrderQuantity) Total_Sales	
from product p
inner join sales s
on p.Product_ID = s.Product_ID
group by Product_Name, year(Sales_Date);

-- 3.Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

select 
	r.Countries, 
    year(s.Sales_Date) Year,
    sum(s.UnitPrice*s.OrderQuantity) Total_Sales
from region r
inner join sales s
on r.Territory_ID = s.Territory_ID
group by r.Countries, year(s.Sales_Date)
order by year(s.Sales_Date), sum(s.UnitPrice*s.OrderQuantity) desc;


-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 

select  
	c.Category_Name,
    count(s.Sales_ID) Product_Demand,
    sum(s.Orderquantity) Total_Quantity
from category c
inner join product p
using (Category_ID)
inner join sales s
using (Product_ID)
group by c.Category_Name;

/* La categoria di articoli più richiesta è "Toys" dato che è presente in numero maggiore nelle transazioni (Sales) individuato grazie al count (Domanda del prodotto),
ulteriore conferma è anche la somma delle quantità degli ordini nelle transazioni. Questi due fattori sono indice di maggior richiesta. */

--  5.Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.

 select *
 from product p
 left join sales s
 on p.Product_ID = s.Product_ID
 where s.Product_ID is null
 order by p.Product_ID ;
 
 
 select product_ID, 
		Product_Name
 from product 
 where product_ID   not in  (
							 select product_ID
							 from sales 
							 group by product_ID )
						order by Product_ID;
 
 /* Ci sono prodotti invenduti e sono racchiusti nelle sovrastanti query.
 Il primo approccio è una left join dove si evidenziano i valori nulli;
 il secondo approccio è una subquery che contiene tutti i singoli product_id che ci sono in sales e la query esterna restiuisce tutti
 i product_id con la clausola where not in (subquery) escludento tutti i prodotti venduti. Di conseguenza la quety complessiva restituisce i prodotti non venduti*/
 
-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

select
	Product_Name,
	max(Sales_Date)	Recent_SalesDate
from product 
inner join sales 
using (Product_ID)
group by Product_Name;